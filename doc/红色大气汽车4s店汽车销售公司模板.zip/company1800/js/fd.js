// JavaScript Document

var productUrl='http://www.newegg.com.cn/Product/paramForProductID.htm';

jQuery(function($) {
    Biz.Product.Product.turn();
    Biz.Product.Product.turn2();
    Biz.Common.TabCtrl.tabs("tab");
	Biz.Common.TabCtrl.tabs("tempTab");
	Biz.Common.MoveCtrl.iniUnit('scroll', 'thumList', 4, 1);
	Biz.Common.MoveCtrl.iniUnit('gift', 'gift_1', 3, 1);
    Biz.Common.MoveCtrl.iniUnit('congener', 'congener_1', 3, 1);
    Biz.Common.TableCtrl.odd();	
    Biz.Product.Product.InitSpecialTable();
    Biz.Product.Product.InitAlsoBuy();

	//Click out event!
	$("#backgroundPopup").click(function(){
		Biz.Common.PopCtrl.disablePopup();
		});
		
	//Press Escape event!
	$(document).keypress(function(e){
		if(e.keyCode==27 && popupStatus==1){
			Biz.Common.PopCtrl.disablePopup();
		}
	});
	
    var options = {
    zoomWidth: 300,
    zoomHeight: 250,
        xOffset: 20,
        yOffset: -0,
        title : false,
		showEffect:"fadein",
		hideEffect:"fadeout",
        position: "right" 
	}
	$(".jqzoom").jqzoom(options);
	
	Biz.Product.ProductDetail.Delay('44891','健康休闲');
}); 
