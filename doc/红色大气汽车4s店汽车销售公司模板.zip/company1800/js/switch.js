// JavaScript Document
$(function(){

    indexSlides.ini();
    latestNews.ini();
    featurePopup.ini();
    
    for(var i=0;i<3;i++){
    var bImgSrc=$('#bi_'+i).find("img").attr("src");
    var bTextSrc=$('#bt_'+i).find("img").attr("src");
    var bButtonSrc=$('#bb_'+i).find("img").attr("src");
    //alert(imgSrc);
    $('#bt_'+i).find("img").addClass("IE6png");
    $('#bb_'+i).find("img").addClass("IE6png");
    $("img[src$='.png']").addClass("IE6png");
    }
    
});

var indexSlides={};

indexSlides.timer=false;
indexSlides.total=$('#slide-index .control a').length;
indexSlides.current=-1;
indexSlides.offScreenLeft=4000;
indexSlides.leaveScreenLeft=4000;
indexSlides.animating=false;

indexSlides.obj=$('#slide-index .slide');

indexSlides.style=[];
indexSlides.style[0]={
    text:{left:'30px',top:'46px'},
    button:{left:'33px',top:'265px'},
    direction:'lr'
};
indexSlides.style[1]={
    text:{left:'30px',top:'81px'},
    button:{left:'30px',top:'244px'},
    direction:'tb'
};
indexSlides.style[2]={
    text:{left:'56px',top:'86px'},
    button:{left:'363px',top:'282px'},
    direction:'lr'
};
//indexSlides.style[3]={
  //  text:{left:'56px',top:'86px'},
  //  button:{left:'363px',top:'282px'},
  //  direction:'lr'
//};

$(document).ready(function(e) {
		setInterval(GetWindowWidth,10);
    });
	function GetWindowWidth(){
       var w = $("#slide-index").innerWidth();
       if (w < 1920){
           $(".image a img").css({"left":(w-1920)/2+"px"});
           }else{
            $(".image a img").css({"left":0+"px"});
        }
}